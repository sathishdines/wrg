$(document).ready(function () {
	
	var swiper = new Swiper(".mySwiper", {
		slidesPerView: 4,
        spaceBetween: 30,
		navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
        scrollbar: {
          el: ".swiper-scrollbar",
          hide: false,
        },
		 breakpoints: {
          320: {
            slidesPerView: 1,
            spaceBetween: 20,
          },
          568: {
            slidesPerView: 2,
            spaceBetween: 40,
          },
          768: {
            slidesPerView: 2,
            spaceBetween: 50,
          },
		  1024: {
            slidesPerView: 3,
            spaceBetween: 50,
          },
		  1280: {
            slidesPerView: 4,
            spaceBetween: 50,
          },
        }
      });
	  
	  $('.bck').backToTop({
            iconName : 'fas fa-arrow-up',
            fxName : 'rightToLeft'
        });
		
		/* function to check screen width */
	function checkWidth() {
		var windowSize = $(window).width();

		if (windowSize < 768) {
			$('.openMenu').show();
			$('.menu').hide();
		} else {
			$('.openMenu').hide();
			$('.menu').show();
		}
	}
	checkWidth();
	$(window).resize(checkWidth);

	/* Mobile menu toggle */
	$('.openMenu').click(function () {
		$('.menu').slideToggle();
	})
		
		



});